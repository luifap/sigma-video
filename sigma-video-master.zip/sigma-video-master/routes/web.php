<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

Auth::routes();

Route::resource('cursos', App\Http\Controllers\UserController::class );
Route::resource('roles', App\Http\Controllers\RoleController::class );
Route::resource('users', App\Http\Controllers\UserController::class );
Route::resource('videos', App\Http\Controllers\VideoController::class );
Route::resource('cursovideo', App\Http\Controllers\cursoVideoController::class );
Route::resource('roleuser', App\Http\Controllers\RoleController::class );
Route::resource('videouser', App\Http\Controllers\VideoUserController::class );

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
